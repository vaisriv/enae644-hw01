# Acknowledgements

- A* Algorithm implemented as per [ENAE644 Course Notes](https://uni.vaisriv.com/26s/ENAE644) and Lavalle's [Planning Algorithms (2006)](https://lavalle.pl/planning).
- Graph Search Display is based off of Dr. Michael Otte's heap and graph search code.
- Graph Data is similarly sourced from the problem statement.
- Heap Implementation from [Hackage::heaps](https://hackage.haskell.org/package/heaps)
